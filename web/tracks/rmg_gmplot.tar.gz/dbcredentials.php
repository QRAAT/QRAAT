<?php
	$hostname = "localhost:/tmp/mysql.sock" ;
	$username = "rmguser" ;
	$password = "rmguserP@55W0RD" ;
	$database = "rmgdata" ;
?>
