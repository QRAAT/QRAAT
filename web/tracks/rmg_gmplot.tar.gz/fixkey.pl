#!/bin/bash
perl -pi -e s/key=AIzaSyDeGV6oAIMTwRJDiEjAcKsulu0jYSsTJsQ/key=AIzaSyChbow-b__qPIiENLEXxm9oa7Mo4FdJsMI/ index.html
